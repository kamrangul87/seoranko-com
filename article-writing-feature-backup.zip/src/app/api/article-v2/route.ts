import { NextRequest } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';
import { stampStage, STAGE } from '@/lib/pages';
import { validateAndCorrect, fetchVerifiedFacts, checkAnswerFirst, computeRankScore, extractHowToSteps, buildInternalLinksPrompt } from '@/lib/article-master';
import { getEligibleLinks } from '@/lib/internal-link-engine';
import type { InternalLink } from '@/lib/article-master';
import { scoreFactDensity } from '@/lib/fact-density';
import { parseFAQsFromArticle } from '@/lib/faq-generator';
import { detectHowTo, type GeneratedSchema } from '@/lib/schema-generator';
import { getBrandSettings } from '@/lib/brand-settings';
import { appendSocialMetaTags } from '@/lib/social-meta-tags';
import { extractArticleDescription, dedupeMetaDescriptionTags } from '@/lib/extract-meta-description';
import { scrubInsertionCorruption, findInsertionCorruptionEvidence } from '@/lib/sentence-integrity';
import { assertImageUrlsPreserved } from '@/lib/html-text-transform';
import { buildCanonicalTag } from '@/lib/canonical-builder';
import { pingIndexNow } from '@/lib/indexnow';
import { humanizeArticle } from '@/lib/humanizer';
import { generateArticleImages } from '@/lib/image-generator';
import { recordScoreSnapshot } from '@/lib/drift-tracker';
import { queueCitationTest } from '@/lib/citation-tester';
import { checkAndPatchFactSourcing } from '@/lib/fact-checker';
import { validateCitationLinks, type CitationLinkIssue } from '@/lib/citation-link-validator';
import {
  calculateEEATScore,
  calculateReadabilityScore,
  analyzeKeywordDensity,
  scoreHtmlLocally,
} from '@/lib/content-scorer';
import { computePanelScores } from '@/lib/panel-scores';
import { MODEL_FOR } from '@/lib/model-router';
import { runQualityGate, detectWrongBrandInBody, recomputeQualityGateTotals, qualityGateStageStatus, buildTimeAnchoredClaimRecords, timeAnchoredClaimFailureToIssue, type QualityIssue } from '@/lib/article-quality-gate';
import { repairTimeAnchoredClaims } from '@/lib/time-anchored-claim-repair';
import { detectTemporalClaims, buildTemporalClaimRows, type TemporalClaim } from '@/lib/temporal-claims';
import { repairTemporalClaims } from '@/lib/temporal-claims-repair';
import { stripStrayDocumentWrapperTags } from '@/lib/html-document-guard';
import { repairAllMergeArtifacts } from '@/lib/merge-artifact-repair';
import { enforceWordCountLimit, countArticleWords, deterministicTrimToTarget, wordCountBand, snapWordCount } from '@/lib/word-count-enforcer';
import { injectMissingInternalLinks } from '@/lib/inject-internal-links';
import { checkTopicAlignment, assertNonEmptyKeyword, keepIfOnTopic, getKeywordTokens, filterRelatedKeywords, primaryTopicPhrase, coreKeywordPhrase } from '@/lib/topic-alignment';
import {
  generateArticleOutline,
  buildOutlineLockedWritePrompt,
} from '@/lib/article-outline';
import { insertTableOfContents } from '@/lib/table-of-contents';
import { toSlugPath } from '@/lib/slug';
import { autoSplitDenseParagraphs } from '@/lib/scannability-fixer';
import { assertSchemaCompleteness } from '@/lib/schema-validate';
import { detectDatedClaims, detectStaleYearReferences, extractHeadingTexts, buildLastVerifiedLine } from '@/lib/dated-claim-detector';
import { enforceDatedPolicy } from '@/lib/dated-policy-enforcer';
import { enforceUnsourcedNumericClaims } from '@/lib/unsourced-numeric-enforcer';
import { enforceHedgeRepetition } from '@/lib/hedge-repetition-enforcer';
import {
  buildFinalArticleArtifact,
} from '@/lib/final-article-artifact';
import {
  resolveLogoPolicy,
  expectOrganizationLogoFromPolicy,
} from '@/lib/quality-gate-policy';
import {
  formatPipelineStageMarker,
  formatPipelineStoppedMarker,
  criticalStopReason,
  stageLabel,
  isCriticalPipelineStopIssue,
  type PipelineStageId,
} from '@/lib/quality-pipeline-stages';

export const maxDuration = 300;

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY!, maxRetries: 5 });

// Service role, not anon — articles/pages/user_profiles RLS is
// auth.uid() = user_id (or = id). A server route has no forwarded user JWT
// by default, so an anon-key client here would have auth.uid() = NULL and
// every insert/update would be silently rejected by RLS. Service role
// bypasses RLS by design; this route already knows and controls which
// user_id to attribute each row to, so it doesn't need RLS to enforce that
// — RLS exists to protect direct client-side DB access, not trusted server
// code. Matches the pattern already used in image-generator.ts and
// internal-link-engine.ts for the same reason.
function getServiceSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } },
  );
}

function auditPlacedLinks(
  articleContent: string,
  requestedLinks: InternalLink[]
): { placed: string[]; skipped: string[] } {
  const placed: string[] = []
  const skipped: string[] = []
  for (const link of requestedLinks) {
    if (!link.url) continue
    const isInArticle = articleContent.includes(link.url)
    if (isInArticle) {
      placed.push(link.url)
    } else {
      skipped.push(link.url)
    }
  }
  return { placed, skipped }
}

function generateLlmsTxtEntry(html: string, keyword: string, url: string): string {
  const isoDate = new Date().toISOString().split('T')[0];
  const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const title = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : keyword;
  const summary = extractArticleDescription(html, keyword) || `${keyword} guide`;
  const h2Matches = Array.from(html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi));
  const topics = h2Matches.map(m => m[1].replace(/<[^>]+>/g, '').trim()).filter(Boolean).slice(0, 6).join(', ');
  return `\n# ${title}\n> ${summary}\nURL: ${url || '/'}\nTopics: ${topics || keyword}\nLast-Updated: ${isoDate}\n`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      keyword: rawKeyword = '',
      wordCount = 2000,
      tone = 'professional',
      market: rawMarket = '',
      secondaryKeywords = [],
      longTailKeywords: _longTailKeywords = [],
      entities = [],
      topicalGaps = [],
      gapAnalysis: _gapAnalysis = undefined,
      domain: rawDomain = '',
      internalLinks: userInternalLinks = [],
      brand = '',
      userId = '',
      pageId = null,
    } = body;

    void _longTailKeywords
    void _gapAnalysis

    let keyword: string
    try {
      keyword = assertNonEmptyKeyword(rawKeyword)
    } catch {
      return new Response(
        JSON.stringify({ error: 'Target keyword is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }
    // ArticleWriter.tsx always sends a real market from its dropdown — this
    // route being called without one is a genuine upstream bug, not a
    // legitimate "no market" case, so it's logged loudly rather than
    // silently assuming a specific country (was previously 'United Kingdom'
    // unconditionally, biasing every market-less request toward UK content).
    if (!rawMarket) {
      console.warn('[article-v2] market missing from request — defaulting to Global. Check the caller: this should always be set from the Write page.');
    }
    const market = rawMarket || 'Global';
    const citationDomain = (rawDomain as string).replace(/^https?:\/\//, '').replace(/\/.*$/, '').toLowerCase().trim();

    console.log('[article-v2] received:', { keyword, wordCount, secondaryKeywords: (secondaryKeywords as string[]).length, entities: (entities as string[]).length });

    // Stale cluster briefs can inject an unrelated secondary (e.g. "near me"
    // while writing "types comparison") and pull the draft off-topic.
    const relatedSecondaries = filterRelatedKeywords(keyword, [
      ...(secondaryKeywords as string[]),
      ...(_longTailKeywords as string[]),
    ])
    const filteredSecondaries = relatedSecondaries.slice(0, 12)
    if (filteredSecondaries.length !== (secondaryKeywords as string[]).length) {
      console.warn('[article-v2] dropped unrelated secondary keywords:', {
        kept: filteredSecondaries,
        dropped: (secondaryKeywords as string[]).filter(k => !filteredSecondaries.includes(k)),
      })
    }

    const targetWordCount = snapWordCount(Number(wordCount) || 2000);
    const secondaryList = filteredSecondaries.join(', ');
    const topicFocus = primaryTopicPhrase(keyword) || coreKeywordPhrase(keyword) || keyword;

    const readable = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        const send = (chunk: string) => controller.enqueue(encoder.encode(chunk));
        const emitStage = (
          id: PipelineStageId,
          status: 'running' | 'pass' | 'fail' | 'fixed' | 'partial' | 'skipped',
          detail?: string,
        ) => {
          send(formatPipelineStageMarker({
            id,
            status,
            label: stageLabel(id),
            ...(detail ? { detail } : {}),
          }));
        };
        const abortCritical = (stageId: PipelineStageId, reason: string) => {
          emitStage(stageId, 'fail', reason);
          send(formatPipelineStoppedMarker({ stageId, reason, critical: true }));
          send(`\n<!--SEORANKO_ERROR:${encodeURIComponent(criticalStopReason(stageId, reason))}-->`);
          controller.close();
        };

        let fullArticle = '';
        try {
          emitStage('research-outline', 'running');
          // ── STEP A — Unique Angle Generator ──────────────────────────────────────
          const angleResponse = await anthropic.messages.create({
            model: MODEL_FOR.keywordExtraction,
            max_tokens: 500,
            messages: [{
              role: 'user',
              content: `You are an editorial director.

      For the keyword: "${keyword}"
      Secondary keywords: ${secondaryList}
      Market: ${market}

      Most articles on this topic cover: basic definitions, general advice, obvious facts.

      Your job: identify ONE specific unique angle that:
      1. Most existing articles completely miss
      2. Answers a real question people have but can't find answered
      3. Contains a surprising insight, counterintuitive fact, or data-driven observation
      4. Cannot be easily replicated by AI Overview summaries

      Respond in JSON only:
      {
        "unique_angle": "one sentence description of the angle",
        "hook_opening": "one surprising opening sentence that grabs attention immediately",
        "unique_section_title": "H2 heading for the unique section nobody else covers",
        "unique_section_content": "150 words of genuinely unique insight for this section"
      }

      Do not write generic angles. Be specific and surprising.`
            }]
          });

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const angleCacheHit = ((angleResponse.usage as any).cache_read_input_tokens ?? 0) > 0;
          console.log(`[model-router] task=keywordExtraction model=${MODEL_FOR.keywordExtraction} inputTokens=${angleResponse.usage.input_tokens} cacheHit=${angleCacheHit}`);
          const angleText = angleResponse.content[0].type === 'text' ? angleResponse.content[0].text : '{}';
          let angle = { unique_angle: '', hook_opening: '', unique_section_title: '', unique_section_content: '' };
          try {
            angle = JSON.parse(angleText.replace(/```json|```/g, '').trim());
          } catch {
            console.error('[article-v2] angle parse failed, continuing without angle');
          }

          // Discard angles that drift off the requested keyword (prevents derailing the write).
          const angleBlob = `${angle.unique_angle} ${angle.unique_section_title} ${angle.unique_section_content}`.toLowerCase();
          const kwTokens = getKeywordTokens(keyword);
          const angleOnTopic = kwTokens.length === 0 || kwTokens.some((t: string) => angleBlob.includes(t));
          if (!angleOnTopic) {
            console.warn('[article-v2] discarding off-topic unique angle for keyword:', keyword);
            angle = { unique_angle: '', hook_opening: '', unique_section_title: '', unique_section_content: '' };
          }

          // MOT-specific injected section removed from the write path — it was
          // previously appended into the master prompt for any EV keyword and diluted
          // topic focus. Outline-locked writing covers MOT only when keyword is MOT.

          // ── STEP B2 — Live fact verification (web search, any topic/country) ──────
          const { facts: liveFacts } = await fetchVerifiedFacts(keyword, market);

          // ── STEP C — Centralised master prompt (shared across all 3 article routes)
          // Brand-aware link registry takes priority over user-provided panel links.
          // Only links that match the article brand AND score relevant are eligible.
          //
          // linksRequestedFromModel tracks whichever list actually got fed into the
          // write prompt, so the post-write audit checks placement against the
          // REAL request — it used to unconditionally audit userInternalLinks even
          // when the registry path was the one actually used, which made a
          // successful registry-link placement report as if nothing had happened.
          let resolvedLinksStr = ''
          let linksRequestedFromModel: InternalLink[] = []
          let linkUnavailableNote = ''
          let homepageGapNote = ''
          if (brand && userId) {
            console.log(`[internal-links] brand="${brand}" userId="${userId}" keyword="${keyword}"`)
            const { links: eligibleLinks, registryRowCount, homepageGapNote: registryHomepageGap } = await getEligibleLinks(userId, brand, keyword, angle.unique_angle || keyword)
            console.log(`[internal-links] ${registryRowCount} active row(s) in registry for this user+brand, ${eligibleLinks.length} scored relevant`)
            if (registryHomepageGap) {
              homepageGapNote = registryHomepageGap
              linkUnavailableNote = registryHomepageGap
              console.log(`[internal-links] homepage gap: ${registryHomepageGap}`)
            }
            if (eligibleLinks.length > 0) {
              const registryLinksAsInternal: InternalLink[] = eligibleLinks.map(l => ({
                url: l.pageUrl,
                anchorText: l.anchorText,
                context: l.pageDescription || l.pageTitle
              }))
              resolvedLinksStr = buildInternalLinksPrompt(registryLinksAsInternal, keyword, angle.unique_angle || keyword)
              linksRequestedFromModel = registryLinksAsInternal
            } else if (!homepageGapNote && registryRowCount === 0) {
              // Distinguish from the "scored too low" case below — this is a
              // data/account problem (zero rows for this user+brand), not a
              // relevance-scoring problem. Confirmed in production: this message
              // used to be identical to the low-score case, which made a wrong-
              // Supabase-account data issue look like a scoring bug.
              linkUnavailableNote = `No internal links are registered for brand "${brand}" on this account. Add entries in Settings → Link Registry — the registry is empty for this user+brand combination.`
            } else if (!homepageGapNote) {
              linkUnavailableNote = `${registryRowCount} link(s) are registered for brand "${brand}", but none scored relevant enough for "${keyword}". Check Settings → Link Registry — the entries may need better topic tags, or genuinely aren't close enough to this article.`
            }
          } else {
            console.warn(`[internal-links] SKIPPED — missing context. brand="${brand}" userId="${userId}". This should not happen if the caller is correctly wired — check that the client is sending both.`)
            linkUnavailableNote = 'No brand or user context for this generation — internal linking from the registry was skipped.'
          }
          // Fall back to user-provided links from InternalLinksPanel only if no registry links found
          if (linksRequestedFromModel.length === 0 && (userInternalLinks as InternalLink[]).length > 0) {
            resolvedLinksStr = buildInternalLinksPrompt(userInternalLinks as InternalLink[], keyword, angle.unique_angle || keyword)
            linksRequestedFromModel = userInternalLinks as InternalLink[]
            linkUnavailableNote = ''
          }
          if (linksRequestedFromModel.length === 0 && !linkUnavailableNote) {
            linkUnavailableNote = 'No internal links were available for this article — neither the registry nor the manual link panel had any entries.'
          }

          // Outline-first: lock H1/H2s to the keyword BEFORE writing body prose.
          const outline = await generateArticleOutline({
            keyword,
            market,
            secondaryKeywords: filteredSecondaries,
            uniqueAngle: angle.unique_angle || '',
            wordCount: targetWordCount,
          })
          if (!outline) {
            abortCritical('research-outline', `Could not build an on-topic outline for "${keyword}". Try again.`);
            return;
          }
          console.log('[article-v2] locked outline:', { h1: outline.h1, h2s: outline.h2s.length })
          emitStage('research-outline', 'pass', `Outline locked (${outline.h2s.length} sections)`);

          // Short keyword-locked write prompt (not the huge master dump — that diluted topic focus).
          const prompt = buildOutlineLockedWritePrompt({
            keyword,
            market,
            tone,
            wordCount: targetWordCount,
            brandName: brand || '',
            brandDomain: citationDomain,
            outline,
            secondaryKeywords: filteredSecondaries,
            liveFacts,
            uniqueAngle: angle.unique_angle || angle.hook_opening || '',
          })
          if (resolvedLinksStr) {
            // Append internal-link instructions after the locked outline prompt
            // without reopening the whole master prompt.
          }
          const writePrompt = resolvedLinksStr
            ? `${prompt}\n\nINTERNAL LINKS (place naturally where relevant):\n${resolvedLinksStr}`
            : prompt

          // ── STEP D — Generate on-topic article FIRST, then stream validated HTML ─
          // Do not stream a live first draft: off-topic stock articles (crypto/LLC/stress)
          // were reaching the UI before retry could replace them.
          const topicSystem = `You write SEO articles as HTML only. This assignment is ONLY about "${keyword}" for the ${market} market. The H1 must clearly be about "${keyword}". Every section must stay on "${keyword}". Author is always Kamran Gul. Never invent other author names. Never switch to a different subject.`;

          const writeOnce = async (userContent: string): Promise<string> => {
            const response = await anthropic.messages.create({
              model: MODEL_FOR.articleWriting,
              max_tokens: 8000,
              system: topicSystem,
              messages: [{ role: 'user', content: userContent }],
            })
            const text = response.content[0].type === 'text' ? response.content[0].text : ''
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const cacheHit = ((response.usage as any).cache_read_input_tokens ?? 0) > 0
            console.log(`[model-router] task=articleWriting model=${MODEL_FOR.articleWriting} inputTokens=${response.usage.input_tokens} cacheHit=${cacheHit}`)
            const fenceStripped = text.replace(/^```html?\n?/i, '').replace(/```\s*$/, '').trim()
            // The model occasionally wraps its draft in a full <!DOCTYPE
            // html><html><head>...</head> document skeleton — articles.content
            // is a body-only fragment by design (the live page supplies its
            // own <head>/<body>), so strip that here, at the single chokepoint
            // every fresh draft passes through, before any later step appends
            // its own canonical/OG/schema tags after the model's stray </html>.
            const { html: docStripped, stripped, strippedTags } = stripStrayDocumentWrapperTags(fenceStripped)
            if (stripped) {
              console.warn(`[article-v2] stripped stray document-wrapper tag(s) from model output: ${strippedTags.join(', ')}`)
            }
            return docStripped
          }

          emitStage('writing-draft', 'running');
          fullArticle = await writeOnce(writePrompt)

          let validated = await validateAndCorrect(fullArticle, keyword, market, liveFacts, brand || '', citationDomain);
          fullArticle = validated.article;
          if (validated.corrections.length > 0) {
            console.log('[article-v2] validation corrections:', validated.corrections);
            emitStage('writing-draft', 'fixed', validated.corrections.slice(0, 3).join('; '));
          } else {
            emitStage('writing-draft', 'pass');
          }

          // Brand/topic alignment — critical early gate (abort before post-processing
          // burns more tokens). Pass status is emitted later in checklist order
          // (after text-integrity); only failures are surfaced here immediately.
          let topicAlignment = checkTopicAlignment(fullArticle, keyword);
          let brandTopicFixed = false;
          if (!topicAlignment.aligned) {
            emitStage('brand-topic', 'running');
            console.error('[article-v2] topic mismatch — retrying from locked outline:', topicAlignment.reason);
            const retryPrompt = buildOutlineLockedWritePrompt({
              keyword,
              market,
              tone,
              wordCount: targetWordCount,
              brandName: brand || '',
              brandDomain: citationDomain,
              outline,
              secondaryKeywords: filteredSecondaries,
              liveFacts,
              uniqueAngle: angle.unique_angle || '',
            })
            const retryText = await writeOnce(
              `${retryPrompt}\n\nIMPORTANT: Previous draft was rejected because it was not about "${topicFocus}". Use the LOCKED H1 and H2s exactly. Write only about "${topicFocus}" (${keyword}). Mention "${topicFocus}" naturally in the introduction and at least two H2 sections.`
            )
            if (retryText.length > 500) {
              fullArticle = retryText;
              validated = await validateAndCorrect(fullArticle, keyword, market, liveFacts, brand || '', citationDomain);
              fullArticle = validated.article;
              topicAlignment = checkTopicAlignment(fullArticle, keyword);
              brandTopicFixed = true;
              console.log('[article-v2] topic retry result:', topicAlignment);
            }
          }

          // Last resort: mechanically lock the H1 to the topic — still abort if
          // body tokens remain off-topic after this (no silent soft-continue).
          if (!topicAlignment.aligned) {
            emitStage('brand-topic', 'running');
            const titleCase = topicFocus
              .split(/\s+/)
              .map(w => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' ')
            const lockedH1 = `${titleCase}: A Practical ${market} Guide`
            if (/<h1[\s>]/i.test(fullArticle)) {
              fullArticle = fullArticle.replace(/<h1[^>]*>[\s\S]*?<\/h1>/i, `<h1>${lockedH1}</h1>`)
            } else {
              fullArticle = `<h1>${lockedH1}</h1>\n${fullArticle}`
            }
            const introNeedle = `<p>This guide covers ${topicFocus} in clear, practical terms for ${market} readers.</p>`
            if (!fullArticle.includes(topicFocus)) {
              fullArticle = fullArticle.replace(/<\/h1>/i, `</h1>\n${introNeedle}`)
            }
            topicAlignment = checkTopicAlignment(fullArticle, keyword)
            brandTopicFixed = true
            console.warn('[article-v2] applied mechanical topic lock:', topicAlignment)
          }

          if (!topicAlignment.aligned) {
            // Stream partial draft so the user can see what failed, then stop.
            send(fullArticle);
            abortCritical(
              'brand-topic',
              topicAlignment.reason || `Draft is not aligned with keyword "${keyword}"`,
            );
            return;
          }

          if (brand) {
            const brandIssue = detectWrongBrandInBody(fullArticle, brand);
            if (brandIssue) {
              emitStage('brand-topic', 'running');
              // validateAndCorrect already tried rival-brand replacement; residual
              // mismatch is a critical stop — do not continue to a wall of issues.
              send(fullArticle);
              abortCritical('brand-topic', brandIssue.title);
              return;
            }
          }

          // Stream the validated draft (post brand/topic gate)
          send(fullArticle);

          try {
            const beforeWc = fullArticle
            fullArticle = await enforceWordCountLimit(fullArticle, targetWordCount);
            fullArticle = keepIfOnTopic(beforeWc, fullArticle, keyword, 'word-count')
          } catch (wcErr) {
            console.warn('[article-v2] word count enforce failed, continuing:', wcErr);
          }

          // === POST-PROCESSING: AEO/GEO enrichment ===
          const { faqs: earlyFaqs } = parseFAQsFromArticle(fullArticle);
          let faqs = earlyFaqs;
          const factDensityResult = scoreFactDensity(fullArticle);
          const isHowTo = detectHowTo(keyword, keyword);
          const titleMatch = fullArticle.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
          const articleTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : keyword;
          // Re-resolved after humanize/schema prep from finalHtml — early value is a placeholder
          let articleDescription = extractArticleDescription(fullArticle, keyword);
          const articleSlug = toSlugPath(keyword);
          // Schema generation moved below, after heroImageUrl is known —
          // real image URL is passed into generateArticleSchema directly.
          const answerFirst = checkAnswerFirst(fullArticle);

          // Score the article and generate llms.txt entry
          // Early draft scores — overwritten from publishedHtml before SEORANKO_SCORES
          // so the Write-page rings always match the same HTML Quality Gate scored.
          let { searchScore, aiScore } = scoreHtmlLocally(fullArticle, keyword);
          let eeatScore = calculateEEATScore(fullArticle);
          let readabilityScore = calculateReadabilityScore(fullArticle);
          const densityTarget = primaryTopicPhrase(keyword) || coreKeywordPhrase(keyword) || keyword;
          const keywordDensityDetail = analyzeKeywordDensity(fullArticle, densityTarget);
          let keywordDensity = keywordDensityDetail.density;
          let keywordDensityScore = keywordDensityDetail.score;
          if (keywordDensityDetail.possibleScoringBug) {
            console.warn(
              `[article-v2] keyword density score (${keywordDensityScore}/100) looks too low given ` +
              `${keywordDensityDetail.occurrences} occurrences of "${densityTarget}" in ${keywordDensityDetail.totalWords} words — check content-scorer.ts for a scoring bug.`
            );
          }
          const rankScore = computeRankScore({
            eeat: eeatScore,
            readability: readabilityScore,
            factDensity: factDensityResult.score,
            hasFAQ: faqs.length >= 4,
            hasSchema: true,
            answerFirst,
          });
          const articleUrl = toSlugPath(keyword);
          const llmsTxtEntry = generateLlmsTxtEntry(fullArticle, keyword, articleUrl);

          // Adaptive image count based on article word count
          const articleWordCount = countArticleWords(fullArticle);
          const adaptiveImageCount = articleWordCount > 2500 ? 5 : articleWordCount > 1500 ? 4 : 3;

          // Humanize + auto-generate images in parallel (both only need the keyword/article text)
          let humanScore: number | undefined;
          let bannedWordsRemoved: string[] = [];
          let passesDetection = false;
          let factSourcingScore: number | undefined;
          let factPatchedCount = 0;
          let articleQualityGate: {
            passed: boolean; score: number; criticalCount: number; warningCount: number;
            autoFixedCount: number; issues: QualityIssue[]; blockers: string[]; readyToPublish: boolean;
          } | undefined;
          let heroImageUrl: string | undefined;
          let primaryImageWidth: number | undefined;
          let temporalClaimsStillFailing: TemporalClaim[] = [];
          // Hoisted so the IndexNow ping (fired after the Supabase save,
          // outside this function's inner try block) can reuse the same
          // full URL already computed for the schema/canonical tag, instead
          // of a third independent computation.
          let fullArticleUrl: string | undefined;
          // Hoisted so the link audit below (and anything else after this
          // try block) can check the actual final text, not the pre-
          // humanization draft — falls back to fullArticle if the try block
          // below fails before reassigning it.
          let finalHtml = fullArticle;
          // What actually gets saved/published — withImages when image
          // injection ran, else finalHtml. Set alongside finalHtml below;
          // separate variable because withImages is scoped inside the
          // `if (imageSet)` block and images are optional.
          let publishedHtml = fullArticle;
          // Hoisted alongside finalHtml/publishedHtml above — built inside
          // the try block once heroImageUrl is known, but referenced again
          // below when the API response is assembled.
          let schemaResult: GeneratedSchema | null = null;
          // One id for this whole generation request — used both as the
          // image storage folder's uniqueness suffix (so two articles on
          // the same keyword never overwrite each other's images, see
          // buildStoragePath) and as the Quality Gate's articleId, so the
          // two logs can be cross-referenced for the same generation.
          const articleInstanceId = crypto.randomUUID();
          // Non-empty means this generation fails a hard pre-save gate
          // (missing figures despite a generated hero image, or missing
          // Article.image/Organization.logo schema per schema-validate.ts)
          // — the Supabase persist step below skips the insert entirely
          // rather than saving a figureless/schema-incomplete article.
          const hardBlockReasons: string[] = [];
          // One instant used for BOTH schema dateModified and the visible
          // "Last verified" line, so the two always agree.
          const generatedAt = new Date().toISOString();
          try {
            emitStage('humanize', 'running');
            const [humanized, imageSet] = await Promise.all([
              // 'light' reuses humanizer.ts's existing cost path: skip Claude
              // entirely if the article already scores >=72 with no banned
              // words, otherwise rewrite with Haiku instead of Sonnet. The
              // automatic pipeline previously hardcoded 'medium' (always a
              // full Sonnet rewrite) even though this cheaper path already
              // existed for exactly this purpose — never wired in here.
              humanizeArticle(fullArticle, { level: 'light', primaryKeyword: keyword }),
              generateArticleImages({
                topic: fullArticle.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').slice(0, 400),
                keyword,
                tier: 'free',
                count: adaptiveImageCount,
                articleInstanceId,
              }).catch((err) => {
                console.warn('[article-v2] auto image generation failed:', err?.message);
                return null;
              }),
            ]);

            humanScore = humanized.humanScore;
            bannedWordsRemoved = humanized.bannedWordsRemoved;
            passesDetection = humanized.passesDetection;

            // ── Sequential body transforms on ONE html variable ──────────
            // Each step below is independently try/caught and REASSIGNS
            // finalHtml only on its own success. This replaced a single
            // broad try/catch spanning this entire stretch: any failure
            // anywhere in it — including in steps with no real relationship
            // to imaging, like getBrandSettings or the canonical-tag
            // builder — silently reset publishedHtml back to the raw
            // pre-humanized draft and discarded the already-resolved
            // imageSet entirely. That's why articles occasionally saved
            // with images successfully generated (confirmed via
            // image_generation_logs) but zero <figure> tags in the saved
            // content: image generation succeeded, but an unrelated LATER
            // step threw, and the one shared catch swallowed everything.
            finalHtml = keepIfOnTopic(fullArticle, humanized.humanizedHtml, keyword, 'humanizer');
            if (finalHtml === fullArticle && humanized.humanizedHtml !== fullArticle) {
              // Humanizer drifted — keep original scores from pre-humanize text
              console.warn('[article-v2] humanizer output discarded due to topic drift')
              emitStage('humanize', 'fixed', 'Humanizer output discarded (topic drift) — kept pre-humanize draft');
            } else if (bannedWordsRemoved.length > 0 || humanized.humanizedHtml !== fullArticle) {
              emitStage('humanize', 'fixed', `Human score ${humanScore ?? '—'}/100${bannedWordsRemoved.length ? `; removed ${bannedWordsRemoved.length} banned word(s)` : ''}`);
            } else {
              emitStage('humanize', 'pass', `Already clean (human score ${humanScore ?? '—'}/100)`);
            }

            emitStage('citation-links', 'running');
            let citationLinkIssues: CitationLinkIssue[] = [];
            try {
              const beforeCite = finalHtml
              const citationCheck = await validateCitationLinks(finalHtml, {
                skipUrls: linksRequestedFromModel.map(l => l.url).filter(Boolean),
                skipDomains: citationDomain ? [citationDomain] : [],
              });
              finalHtml = keepIfOnTopic(beforeCite, citationCheck.html, keyword, 'citation-links');
              citationLinkIssues = citationCheck.issues;
              if (citationLinkIssues.length > 0) {
                console.warn(
                  `[article-v2] citation link validation: stripped ${citationLinkIssues.length} broken/fake citation link(s):`,
                  citationLinkIssues.map(i => `${i.url} (${i.reason}: ${i.detail})`)
                );
                emitStage('citation-links', 'fixed', `Stripped ${citationLinkIssues.length} broken/fake citation link(s)`);
              } else {
                emitStage('citation-links', 'pass', 'All citation links validated');
              }
            } catch (citationErr) {
              console.warn('[article-v2] citation link validation failed, continuing:', citationErr);
              emitStage('citation-links', 'pass', 'Citation check skipped (validator error) — continuing');
            }

            emitStage('fact-checking', 'running');
            try {
              const beforeFact = finalHtml
              const factResult = await checkAndPatchFactSourcing(finalHtml, keyword, market);
              finalHtml = keepIfOnTopic(beforeFact, factResult.article, keyword, 'fact-sourcing');
              factSourcingScore = factResult.result.factSourcingScore;
              factPatchedCount = factResult.result.patchedCount;
              if (factPatchedCount > 0) {
                console.log(`[article-v2] fact-sourcing: patched ${factPatchedCount} unsourced claims, score=${factSourcingScore}`);
                emitStage('fact-checking', 'fixed', `Patched ${factPatchedCount} unsourced claim(s); score ${factSourcingScore}/100`);
              } else {
                emitStage('fact-checking', 'pass', `Fact sourcing score ${factSourcingScore ?? '—'}/100`);
              }
            } catch (factErr) {
              console.warn('[article-v2] fact-sourcing check failed, continuing:', factErr);
              emitStage('fact-checking', 'pass', 'Fact-check skipped (error) — continuing');
            }

            // Fact-sourcing patches can introduce their own merge artifacts —
            // repair before the Quality Gate scores the article. humanizeArticle
            // already ran its own repair pass on humanized.humanizedHtml; this
            // catches anything the fact-sourcing patch introduced afterward.
            emitStage('text-integrity', 'running');
            let integrityFixed = 0;
            try {
              const beforeRepair = finalHtml
              const repairResult = await repairAllMergeArtifacts(finalHtml);
              finalHtml = keepIfOnTopic(beforeRepair, repairResult.content, keyword, 'merge-repair');
              integrityFixed += repairResult.repairsMade;
              if (repairResult.repairsMade > 0) {
                console.log(`[article-v2] merge-artifact repair: fixed ${repairResult.repairsMade} broken sentence(s)`);
              }
            } catch (repairErr) {
              console.warn('[article-v2] merge-artifact repair failed, continuing:', repairErr);
            }

            const scrubPass = scrubInsertionCorruption(finalHtml);
            finalHtml = scrubPass.html;
            integrityFixed += scrubPass.fixes;
            const residual = findInsertionCorruptionEvidence(finalHtml)
            if (residual) {
              send(finalHtml);
              abortCritical(
                'text-integrity',
                `Residual merge/insertion corruption remains after repair: "${residual}". Generation stopped — regenerate or edit manually.`,
              );
              return;
            }
            emitStage(
              'text-integrity',
              integrityFixed > 0 ? 'fixed' : 'pass',
              integrityFixed > 0
                ? `Repaired ${integrityFixed} integrity issue(s)`
                : 'No merge artifacts or insertion corruption detected',
            );

            // Mechanical date-anchor removal BEFORE the gate scores the
            // article: detection + 90-day review scheduling never changed the
            // shipped text, so "As of <month year>, …" survived into every
            // article and the dated-policy warning recurred. Claims the
            // stripper can't safely rewrite are left in place and still reach
            // the gate / freshness review below.
            try {
              const datedPolicy = enforceDatedPolicy(finalHtml, new Date(generatedAt));
              if (datedPolicy.strippedCount > 0) {
                finalHtml = keepIfOnTopic(finalHtml, datedPolicy.html, keyword, 'date-anchor-strip');
                console.log(
                  `[article-v2] date-anchor strip: removed ${datedPolicy.strippedCount} anchor(s) [${datedPolicy.appliedRules.join(', ')}], ` +
                  `${datedPolicy.remainingTimeAnchored.length} time-anchored claim(s) remain`,
                );
              }
            } catch (stripErr) {
              console.warn('[article-v2] date-anchor strip failed, continuing:', stripErr);
            }

            // Mechanical unsourced £/%/deadline generalization + AI-slop
            // phrase removal BEFORE the gate scores the article. Prompt
            // rules alone do not stop the model inventing grant figures;
            // claim-evidence / score-floor then fire on every run. Claims
            // that remain unsupported after stripping still reach the gate.
            try {
              const numericEnforce = enforceUnsourcedNumericClaims(finalHtml);
              if (numericEnforce.strippedCount > 0 || numericEnforce.aiSlop.strippedCount > 0) {
                finalHtml = keepIfOnTopic(finalHtml, numericEnforce.html, keyword, 'unsourced-numeric-strip');
                console.log(
                  `[article-v2] unsourced-numeric strip: generalized ${numericEnforce.strippedCount} figure(s)` +
                  `${numericEnforce.strippedFigures.length ? ` [${numericEnforce.strippedFigures.slice(0, 8).join(', ')}]` : ''}, ` +
                  `${numericEnforce.remainingUnsourced.length} unsourced claim(s) remain; ` +
                  `ai-slop removed ${numericEnforce.aiSlop.strippedCount}`,
                );
              }
            } catch (numericErr) {
              console.warn('[article-v2] unsourced-numeric strip failed, continuing:', numericErr);
            }

            // Cap repeated hedge boilerplate (typically/generally/…) before the
            // gate scores readability — keep the first few uses, drop the rest.
            try {
              const hedgeEnforce = enforceHedgeRepetition(finalHtml);
              if (hedgeEnforce.removedCount > 0) {
                finalHtml = keepIfOnTopic(finalHtml, hedgeEnforce.html, keyword, 'hedge-repetition-strip');
                console.log(
                  `[article-v2] hedge-repetition strip: removed ${hedgeEnforce.removedCount} excess hedge(s)` +
                  ` [${Object.entries(hedgeEnforce.removedByToken).map(([t, n]) => `${t}×${n}`).join(', ')}]` +
                  `${hedgeEnforce.stillRepetitive ? ' (residual repetition remains)' : ''}`,
                );
              }
            } catch (hedgeErr) {
              console.warn('[article-v2] hedge-repetition strip failed, continuing:', hedgeErr);
            }

            // Dated-claim / stale-year detection now lives inside runQualityGate
            // (buildDatedPolicyIssues) so recheck and Fix All use the same
            // findings and DATED_POLICY_SEVERITY. article-v2 only logs here
            // for early visibility before the final artifact is built.
            try {
              const datedClaims = detectDatedClaims(finalHtml, new Date(generatedAt));
              const unsourced = datedClaims.filter(c => !c.hasSource)
              const uniqueUnsourced = Array.from(
                new Map(unsourced.map(c => [c.sentence.trim(), c])).values()
              )
              if (uniqueUnsourced.length > 0) {
                console.warn(`[article-v2] dated-claim-detector: ${uniqueUnsourced.length} unsourced dated claim(s) found (will surface via Quality Gate)`);
              }
            } catch (datedErr) {
              console.warn('[article-v2] dated-claim detection failed, continuing:', datedErr);
            }

            try {
              const publishYear = new Date(generatedAt).getFullYear();
              const staleYears = detectStaleYearReferences(
                { title: articleTitle, headings: extractHeadingTexts(finalHtml), metaDescription: articleDescription },
                publishYear,
              );
              if (staleYears.length > 0) {
                console.warn(`[article-v2] stale-year check: ${staleYears.length} year reference(s) don't match publish year ${publishYear}`);
              }
            } catch (staleYearErr) {
              console.warn('[article-v2] stale-year check failed, continuing:', staleYearErr);
            }

            if (imageSet?.hero?.url) {
              heroImageUrl = imageSet.hero.url;
            }

            // Final word-count gate AFTER humanize/fact patches — soft ±12% band.
            // Early condense can be undone by later rewrites; expand if under min.
            try {
              const beforeFinalWc = finalHtml
              finalHtml = await enforceWordCountLimit(finalHtml, targetWordCount)
              finalHtml = keepIfOnTopic(beforeFinalWc, finalHtml, keyword, 'final-word-count')
              const { max: maxBand } = wordCountBand(targetWordCount)
              if (countArticleWords(finalHtml) > maxBand) {
                const trimmed = deterministicTrimToTarget(finalHtml, targetWordCount)
                finalHtml = keepIfOnTopic(finalHtml, trimmed, keyword, 'deterministic-trim')
              }
              console.log(`[article-v2] final word count: ${countArticleWords(finalHtml)} (target ${targetWordCount})`)
            } catch (wcErr) {
              console.warn('[article-v2] final word-count enforce failed:', wcErr)
            }

            // Re-parse FAQs from post-humanize HTML so FAQPage schema matches visible content
            faqs = parseFAQsFromArticle(finalHtml).faqs

            // Inject real <a href> anchors for any requested internal links the model skipped
            if (linksRequestedFromModel.length > 0) {
              const linkInject = injectMissingInternalLinks(finalHtml, linksRequestedFromModel)
              finalHtml = linkInject.html
              if (linkInject.injected.length > 0) {
                console.log(`[internal-links] injected clickable anchors: ${linkInject.injected.join(', ')}`)
              }
              if (linkInject.skipped.length > 0) {
                console.log(
                  `[internal-links] skipped homepage/figure placements: ${linkInject.skipped.map((s) => `${s.url} (${s.reason})`).join('; ')}`,
                )
              }
            }

            // ── FINAL ARTIFACT PIPELINE (Phase 1) ──────────────────────────
            // Order: prose → images → paragraph/scannability → schema sync →
            // final Quality Gate → score/save/stream. The same canonical HTML
            // must drive publish, save, UI stream, and final QG scoring.
            // See FINAL_ARTIFACT_PIPELINE_ORDER in final-article-artifact.ts.

            // Schema publisher identity — never SEORANKO as a silent default.
            const schemaOrgName = brand || citationDomain || 'this site';
            // organizationUrl previously ONLY came from the separate `domain`
            // field — if that was empty (as here: brand='ev.autodun.com' but
            // domain='') it silently fell back to generateArticleSchema's own
            // default (https://seoranko.com), publishing SEORANKO itself as
            // the article's publisher. Brand is very often itself a domain
            // (e.g. 'ev.autodun.com', 'autodun.com') — use it directly when
            // it looks like one and no separate domain was supplied.
            const brandLooksLikeDomain = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(brand.trim());
            const schemaOrgUrl = citationDomain
              ? `https://${citationDomain}`
              : brandLooksLikeDomain
                ? `https://${brand.trim()}`
                : undefined;
            // Shared by the JSON-LD schema below, the OG/Twitter tags, the
            // canonical tag, and the IndexNow ping after save — one full
            // canonical-style URL, computed once. Hoisted (see
            // `let fullArticleUrl` above) so the IndexNow ping, which fires
            // outside this try block after the Supabase save, can reuse it.
            fullArticleUrl = schemaOrgUrl ? `${schemaOrgUrl}${articleSlug}` : `https://example.com${articleSlug}`;

            // brand_settings.logo_url — feeds Organization/Article-publisher
            // schema's logo. Quality Gate gets expectOrganizationLogo below
            // so validator matches generator when logo_url is unset. Own
            // try/catch: a Supabase lookup failure here must not discard
            // already-successful humanization/images.
            let brandSettings: { configured: boolean; logoUrl: string | null } = { configured: false, logoUrl: null };
            try {
              brandSettings = brand ? await getBrandSettings(userId as string, brand) : { configured: false, logoUrl: null };
            } catch (brandErr) {
              console.warn('[article-v2] getBrandSettings failed, continuing without brand settings:', brandErr);
            }
            const logoPolicy = resolveLogoPolicy({ brandSettings });

            // Re-extract after humanize/fact patches so META hyphens & model tags stay in sync
            articleDescription = extractArticleDescription(finalHtml, keyword) || articleDescription;

            try {
              // Mechanical scannability safety net on prose (before images).
              finalHtml = autoSplitDenseParagraphs(finalHtml);
            } catch (splitErr) {
              console.warn('[article-v2] autoSplitDenseParagraphs failed, continuing:', splitErr);
            }

            try {
              finalHtml = insertTableOfContents(finalHtml, countArticleWords(finalHtml));
            } catch (tocErr) {
              console.warn('[article-v2] insertTableOfContents failed, continuing:', tocErr);
            }

            // Brand/topic confirmation before final-artifact assembly
            emitStage('brand-topic', 'running');
            const postProcessTopic = checkTopicAlignment(finalHtml, keyword);
            if (!postProcessTopic.aligned) {
              abortCritical(
                'brand-topic',
                postProcessTopic.reason || `Article drifted off keyword "${keyword}" during post-processing`,
              );
              return;
            }
            if (brand) {
              const lateBrandIssue = detectWrongBrandInBody(finalHtml, brand);
              if (lateBrandIssue) {
                abortCritical('brand-topic', lateBrandIssue.title);
                return;
              }
            }
            emitStage(
              'brand-topic',
              brandTopicFixed ? 'fixed' : 'pass',
              brandTopicFixed
                ? 'Topic/brand corrected earlier; still aligned after post-processing'
                : 'Brand and topic match the brief',
            );

            // Progressive UX: stream prose snapshot (not used for final QG/save)
            controller.enqueue(encoder.encode(
              `\n<!--SEORANKO_HUMANIZED_START-->\n${finalHtml}\n<!--SEORANKO_HUMANIZED_END-->`
            ));

            // ── Build canonical final artifact (images → split → schema) ──
            emitStage('schema-check', 'running');
            let gateEeat = calculateEEATScore(finalHtml)
            let gateDensity = analyzeKeywordDensity(
              finalHtml,
              primaryTopicPhrase(keyword) || coreKeywordPhrase(keyword) || keyword,
            )
            try {
              const artifact = buildFinalArticleArtifact({
                proseHtml: finalHtml,
                imageSet,
                schemaInput: {
                  title: articleTitle,
                  description: articleDescription,
                  keyword,
                  market,
                  // generateArticleSchema hardcodes author.@type to "Person" —
                  // organizationName below is the correctly-typed publisher.
                  authorName: 'Kamran Gul',
                  publishDate: generatedAt,
                  dateModified: generatedAt,
                  articleUrl: fullArticleUrl!,
                  faqs: faqs.length > 0 ? faqs : undefined,
                  isHowTo,
                  howToSteps: isHowTo ? extractHowToSteps(fullArticle) : undefined,
                  organizationName: schemaOrgName,
                  organizationUrl: schemaOrgUrl,
                  organizationLogoUrl: brandSettings.logoUrl || undefined,
                },
                enrichBeforeSchema: (html, primaryImageUrl) => {
                  let enriched = html
                  try {
                    enriched = appendSocialMetaTags(enriched, {
                      title: articleTitle,
                      description: articleDescription,
                      url: fullArticleUrl!,
                      imageUrl: primaryImageUrl || heroImageUrl,
                    });
                  } catch (socialErr) {
                    console.warn('[article-v2] social meta tags failed, continuing without them:', socialErr);
                  }
                  enriched = dedupeMetaDescriptionTags(enriched);
                  try {
                    enriched = `${enriched}\n\n${buildCanonicalTag(fullArticleUrl!)}`;
                  } catch (canonicalErr) {
                    console.warn('[article-v2] canonical tag failed, continuing without it:', canonicalErr);
                  }
                  try {
                    enriched = `${enriched}\n\n${buildLastVerifiedLine(generatedAt)}`;
                  } catch (verifiedErr) {
                    console.warn('[article-v2] "Last verified" line failed, continuing without it:', verifiedErr);
                  }
                  return enriched
                },
              });

              if (artifact.imageHandOffError) {
                hardBlockReasons.push(artifact.imageHandOffError);
                console.error('[article-v2] image injection post-condition failed:', artifact.imageHandOffError);
              }
              // Post-conditions re-verified on the synchronized artifact: the
              // repairs above are only trusted when their own validator agrees.
              if (artifact.schemaImageError) {
                hardBlockReasons.push(artifact.schemaImageError);
                console.error('[article-v2] Article.image post-condition failed:', artifact.schemaImageError);
              }
              if (artifact.scannabilityError) {
                hardBlockReasons.push(artifact.scannabilityError);
                console.error('[article-v2] scannability post-condition failed:', artifact.scannabilityError);
              }
              if (artifact.documentStructureError) {
                hardBlockReasons.push(artifact.documentStructureError);
                console.error('[article-v2] document-structure post-condition failed:', artifact.documentStructureError);
              }

              schemaResult = artifact.schemaResult;
              if (artifact.primaryImageUrl) {
                heroImageUrl = artifact.primaryImageUrl;
              }
              primaryImageWidth = artifact.primaryImageWidth;
              publishedHtml = artifact.html;

              // Hard publish/save gate on the SYNCHRONIZED artifact (distinct
              // from Quality Gate schema recommendations below).
              const schemaCheck = assertSchemaCompleteness({
                imageUrl: schemaResult.imageUrl,
                organizationLogoUrl: schemaResult.organizationLogoUrl,
                logoOmittedReason: schemaResult.logoOmittedReason,
                hasBrandSettingsConfigured: brandSettings.configured,
              });
              if (schemaCheck.blocked) {
                hardBlockReasons.push(...schemaCheck.reasons);
                console.error('[article-v2] schema completeness check failed:', schemaCheck.reasons);
                emitStage('schema-check', 'fail', schemaCheck.reasons.join(' | '));
              } else {
                emitStage(
                  'schema-check',
                  'pass',
                  brandSettings.logoUrl
                    ? 'Article/Organization schema complete on final artifact (incl. logo)'
                    : 'Article schema complete on final artifact (Organization logo not configured for this brand)',
                );
              }

              if (imageSet) {
                controller.enqueue(encoder.encode(
                  `\n<!--SEORANKO_WITH_IMAGES_START-->\n${publishedHtml}\n<!--SEORANKO_WITH_IMAGES_END-->`
                ));
                controller.enqueue(encoder.encode(
                  `\n<!--SEORANKO_IMAGE_SET_START-->${JSON.stringify({
                    images: [imageSet.hero, ...imageSet.content].map(img => ({ ...img, altText: img.alt })),
                    stored: [imageSet.hero, ...imageSet.content].some(img => img.url.includes('supabase')),
                    niche: imageSet.niche,
                    styleDescriptor: imageSet.styleDescriptor,
                    imageStats: imageSet.imageStats,
                  })}<!--SEORANKO_IMAGE_SET_END-->`
                ));
              }

              // ── Final Quality Gate on the SAME canonical artifact ──────
              emitStage('quality-gate', 'running');
              const registeredDomains = citationDomain
                ? [citationDomain]
                : (brand ? [`${brand}.com`] : [])
              const wcBand = wordCountBand(targetWordCount)
              gateEeat = calculateEEATScore(publishedHtml)
              gateDensity = analyzeKeywordDensity(
                publishedHtml,
                primaryTopicPhrase(keyword) || coreKeywordPhrase(keyword) || keyword,
              )
              const imageExtraIssues: QualityIssue[] = []
              // Soft case only: assertSchemaCompleteness already hard-blocks
              // the save when a *configured* brand has no resolvable logo.
              // This is the non-blocking case — brand has no brand_settings
              // row at all yet — surfaced as a UI nudge rather than silently
              // shipping an Organization with no logo.
              if (schemaResult.logoOmittedReason && !brandSettings.configured) {
                imageExtraIssues.push({
                  id: 'schema-logo-not-configured',
                  severity: 'info',
                  category: 'schema',
                  title: 'Organization logo not configured — publisher.logo omitted',
                  description: `${schemaResult.logoOmittedReason} Add a logo in Brand Settings to include Organization.logo in this article's schema.`,
                  autoFixable: false,
                })
              }
              if (imageSet && imageSet.imageStats.failures.length > 0) {
                imageExtraIssues.push({
                  id: 'image-count-mismatch',
                  severity: 'warning',
                  category: 'image-completeness',
                  title: `${imageSet.imageStats.failures.length} image(s) failed to generate`,
                  description: `This article was supposed to have ${imageSet.imageStats.requested} images but only ${imageSet.imageStats.generated} generated successfully. Every image provider (Gemini, Pexels, pollinations.ai) failed for at least one slot — check API keys and daily rate limits: ${imageSet.imageStats.failures.join('; ')}`,
                  autoFixable: false,
                })
              }
              if (artifact.imageHandOffError) {
                imageExtraIssues.push({
                  id: 'image-figure-hand-off-failed',
                  severity: 'critical',
                  category: 'image-completeness',
                  title: 'Hero image generated but not present in article HTML',
                  description: artifact.imageHandOffError,
                  autoFixable: false,
                })
              }
              const qr = await runQualityGate(publishedHtml, {
                brand,
                keyword,
                authorName: 'Kamran Gul',
                registeredLinkDomains: registeredDomains,
                minWordCount: wcBand.min,
                maxWordCount: wcBand.max,
                maxTypically: 5,
                userId: (userId as string) || undefined,
                articleId: articleInstanceId,
                brief: (entities as string[]).length > 0 || (topicalGaps as string[]).length > 0
                  ? { entities: entities as string[], topicalGaps: topicalGaps as string[] }
                  : undefined,
                secondaryKeywords: filteredSecondaries,
                extraIssues: imageExtraIssues,
                primaryImageWidth,
                organizationLogoUrl: schemaResult.organizationLogoUrl,
                datedPolicy: {
                  now: new Date(generatedAt),
                  title: articleTitle,
                  metaDescription: articleDescription,
                },
                expectOrganizationLogo: expectOrganizationLogoFromPolicy(logoPolicy),
                eeatScore: gateEeat,
                keywordDensityPct: gateDensity.density,
                keywordDensityScore: gateDensity.score,
                factSourcingScore,
                humanScore,
              })
              publishedHtml = qr.articleAfterAutoFix
              finalHtml = publishedHtml
              articleQualityGate = {
                passed: qr.passed, score: qr.score, criticalCount: qr.criticalCount,
                warningCount: qr.warningCount, autoFixedCount: qr.autoFixedCount,
                issues: qr.issues, blockers: qr.blockers, readyToPublish: qr.readyToPublish,
              }
              if (qr.autoFixedCount > 0) console.log(`[article-v2] quality-gate: auto-fixed ${qr.autoFixedCount} issues, score=${qr.score}`)

              const beforePostGateScrub = publishedHtml
              publishedHtml = scrubInsertionCorruption(publishedHtml).html
              assertImageUrlsPreserved(beforePostGateScrub, publishedHtml)
              finalHtml = publishedHtml

              // C04 Step 1.4 — mechanical single-sentence repair loop. Only
              // runs when the gate found unresolved time-anchored claims;
              // touches only the flagged sentences, never a whole-article
              // rewrite (banned by rule A02).
              if (qr.issues.some(i => i.id.startsWith('time-anchored-claim-'))) {
                try {
                  const repair = await repairTimeAnchoredClaims(publishedHtml, new Date(generatedAt))
                  if (repair.repairedCount > 0) {
                    publishedHtml = repair.article
                    finalHtml = publishedHtml
                  }
                  console.log(`[article-v2] time-anchored-claim repair: fixed ${repair.repairedCount}, ${repair.stillFailing.length} still failing`)
                  if (articleQualityGate) {
                    const keptIssues = articleQualityGate.issues.filter(i => !i.id.startsWith('time-anchored-claim-'))
                    const rebuiltIssues = repair.stillFailing.map((f, i) => timeAnchoredClaimFailureToIssue(f, i))
                    articleQualityGate = recomputeQualityGateTotals({
                      ...articleQualityGate,
                      issues: [...keptIssues, ...rebuiltIssues],
                      articleAfterAutoFix: publishedHtml,
                      autoFixedCount: (articleQualityGate.autoFixedCount || 0) + repair.repairedCount,
                    })
                  }
                } catch (repairErr) {
                  console.warn('[article-v2] time-anchored-claim repair failed, continuing with original issues:', repairErr)
                }
              }

              // C04 (temporal-claims spec) — stricter same-sentence-citation
              // sibling to the block above. Detection always runs (not
              // gated behind a prior QG finding, since this system isn't
              // wired into the QG issue list the way the older one is);
              // repair only fires when detection actually finds an unbound
              // marker+figure sentence.
              try {
                const temporalRepair = await repairTemporalClaims(publishedHtml)
                if (temporalRepair.repairedCount > 0) {
                  publishedHtml = temporalRepair.article
                  finalHtml = publishedHtml
                }
                temporalClaimsStillFailing = temporalRepair.stillFailing
                if (temporalRepair.repairedCount > 0 || temporalClaimsStillFailing.length > 0) {
                  console.log(`[article-v2] temporal-claims repair: fixed ${temporalRepair.repairedCount}, ${temporalClaimsStillFailing.length} still failing`)
                }
                if (articleQualityGate && temporalClaimsStillFailing.length > 0) {
                  const temporalIssues: QualityIssue[] = temporalClaimsStillFailing.map((c, i) => ({
                    id: `temporal-claim-${i}`,
                    severity: 'critical',
                    category: 'dated-policy',
                    title: `Time-anchored claim — no citation in this sentence: "${c.qualifyingTerm}"`,
                    description: `"${c.sentence}" — matched temporal marker "${c.matchedMarker}" with no outbound citation in the same sentence. Add a source link in this exact sentence.`,
                    location: c.sentence.slice(0, 100),
                    autoFixable: false,
                  }))
                  articleQualityGate = recomputeQualityGateTotals({
                    ...articleQualityGate,
                    issues: [...articleQualityGate.issues, ...temporalIssues],
                    articleAfterAutoFix: publishedHtml,
                    autoFixedCount: (articleQualityGate.autoFixedCount || 0) + temporalRepair.repairedCount,
                  })
                }
              } catch (temporalErr) {
                console.warn('[article-v2] temporal-claims repair failed, continuing:', temporalErr)
              }

              const criticalStops = qr.issues.filter(i => isCriticalPipelineStopIssue(i))
              if (criticalStops.length > 0) {
                const reason = criticalStops.map(i => i.title).join(' | ')
                send(`\n<!--SEORANKO_HUMANIZED_START-->\n${publishedHtml}\n<!--SEORANKO_HUMANIZED_END-->`)
                // Rings + Quality Gate must describe the SAME published HTML
                const panel = computePanelScores(publishedHtml, keyword)
                eeatScore = panel.eeatScore
                readabilityScore = panel.readabilityScore
                keywordDensity = panel.keywordDensity
                keywordDensityScore = panel.keywordDensityScore
                const partialMeta = JSON.stringify({
                  qualityGate: articleQualityGate,
                  eeatScore,
                  readabilityScore,
                  keywordDensity,
                  keywordDensityScore,
                  factSourcingScore,
                  humanScore,
                  pipelineStopped: true,
                  pipelineStopReason: reason,
                })
                send(`\n<!-- SEORANKO_SCORES:${partialMeta} -->`)
                abortCritical('quality-gate', reason)
                return
              }
              // Final quality-gate stage status is emitted once below from the
              // single post-save-topic reading of articleQualityGate.
            } catch (finalErr) {
              console.warn('[article-v2] final artifact / quality gate failed, continuing:', finalErr)
              emitStage(
                'schema-check',
                'fail',
                finalErr instanceof Error ? finalErr.message : 'Final artifact assembly failed',
              )
              emitStage(
                'quality-gate',
                'fail',
                finalErr instanceof Error ? finalErr.message : 'Quality Gate error',
              )
              publishedHtml = finalHtml
            }
          } catch (err) {
            console.warn('[article-v2] humanization/images failed, continuing without:', err);
          }

          // Audit against whichever list was actually requested from the
          // model (registry-sourced links take priority — see STEP C), not
          // unconditionally the user-provided panel list, and against the
          // final processed text so placement reflects what's really shipping.
          const placementResult = auditPlacedLinks(publishedHtml, linksRequestedFromModel);
          const linkAudit = {
            ...placementResult,
            totalPlaced: placementResult.placed.length,
            note: homepageGapNote || (
              placementResult.placed.length === 0
                ? (linkUnavailableNote || 'Links were requested but none were placed naturally in the article text — check the skipped list for reasons.')
                : undefined
            ),
          };
          console.log(`[internal-links] placed=${linkAudit.totalPlaced} skipped=${placementResult.skipped.length}${linkAudit.note ? ` note="${linkAudit.note}"` : ''}`);

          // Single prose word count after ALL transforms — UI, DB, schema, and QG must agree
          const finalProseWordCount = countArticleWords(publishedHtml)

          // Structured copy of the JSON-LD already embedded as <script> tags
          // inside publishedHtml — for the hosted publish route to inject
          // directly (single source: schemaResult) rather than re-parsing it
          // back out of the content HTML at render time.
          const schemaJsonForDb = schemaResult
            ? [
                schemaResult.articleSchema,
                schemaResult.faqSchema,
                schemaResult.howToSchema,
                schemaResult.breadcrumbSchema,
                schemaResult.organizationSchema,
              ]
                .filter((s): s is string => !!s)
                .map(s => {
                  try { return JSON.parse(s) } catch { return null }
                })
                .filter(Boolean)
            : null;

          // C04: every time-anchored figure detected on the final canonical
          // HTML, for later re-verification by reviewBy — empty array is a
          // genuine "none found", not a failure.
          let timeAnchoredClaimsForDb: ReturnType<typeof buildTimeAnchoredClaimRecords> = [];
          try {
            timeAnchoredClaimsForDb = buildTimeAnchoredClaimRecords(publishedHtml, new Date(generatedAt));
          } catch (timeAnchoredErr) {
            console.warn('[article-v2] time-anchored-claims extraction failed, continuing:', timeAnchoredErr);
          }

          // C04 (temporal-claims spec) registry rows — needs the real saved
          // article id, so only the CLAIMS are computed here; the actual
          // temporal_claims insert happens right after the articles insert
          // below, once savedArticleId exists.
          let finalTemporalClaims: TemporalClaim[] = [];
          try {
            finalTemporalClaims = detectTemporalClaims(publishedHtml);
          } catch (temporalDetectErr) {
            console.warn('[article-v2] temporal-claims extraction failed, continuing:', temporalDetectErr);
          }

          // ── Persist to Supabase ──────────────────────────────────────────
          // This is the entire reason the `articles` table had 0 rows in
          // production: this route streamed the generated article back to
          // the browser and never wrote it anywhere. Every downstream reader
          // (Topical Map, Cannibalisation Detector, ROI Dashboard, RANKO
          // diagnose) was correctly showing empty — there was genuinely
          // nothing there. A save failure here must not silently produce a
          // 200 with a generated-but-unsaved article — see saveError below,
          // surfaced through SEORANKO_SCORES rather than the fatal
          // SEORANKO_ERROR marker, since the article itself is still good;
          // only persistence failed, and discarding a successful generation
          // over that would be a worse outcome than the current bug.
          let savedArticleId: string | undefined;
          let saveError: string | undefined;
          const saveTopicCheck = checkTopicAlignment(publishedHtml, keyword);
          if (!saveTopicCheck.aligned) {
            // Do not discard — save proceeds; Quality Gate already scores keyword density.
            console.warn('[article-v2] pre-save topic soft-warn:', saveTopicCheck.reason);
            if (articleQualityGate) {
              articleQualityGate = recomputeQualityGateTotals({
                ...articleQualityGate,
                issues: [
                  ...articleQualityGate.issues,
                  {
                    id: 'topic-alignment',
                    severity: 'warning',
                    category: 'topic-alignment',
                    title: 'Topic alignment is weak',
                    description: saveTopicCheck.reason || 'Review the H1 and keyword mentions before publishing',
                    autoFixable: false,
                  },
                ],
                articleAfterAutoFix: publishedHtml,
              })
            }
          } else if (saveTopicCheck.warning && articleQualityGate) {
            articleQualityGate = recomputeQualityGateTotals({
              ...articleQualityGate,
              issues: [
                ...articleQualityGate.issues,
                {
                  id: 'topic-alignment-light',
                  severity: 'info',
                  category: 'topic-alignment',
                  title: 'Keyword density is light',
                  description: saveTopicCheck.warning,
                  autoFixable: false,
                },
              ],
              articleAfterAutoFix: publishedHtml,
            })
          }

          // Single source of truth for pipeline stage + Article Scores panel:
          // recompute once after every post-QG mutation, then emit Final Quality
          // Gate from that same object (also sent in SEORANKO_SCORES).
          if (articleQualityGate) {
            articleQualityGate = recomputeQualityGateTotals({
              ...articleQualityGate,
              articleAfterAutoFix: publishedHtml,
            })
            const stage = qualityGateStageStatus(articleQualityGate)
            emitStage(
              'quality-gate',
              stage.status,
              `Score ${articleQualityGate.score}/100 · ${stage.detailSuffix}` +
                (articleQualityGate.autoFixedCount
                  ? ` · ${articleQualityGate.autoFixedCount} auto-fixed`
                  : ''),
            )
          }
          if (hardBlockReasons.length > 0) {
            // FIX 1 / FIX 2 hard gate: a hero image was generated but never
            // made it into the HTML, or Article.image/Organization.logo
            // schema is missing/invalid. The article is still streamed back
            // to the client above for visibility/debugging, but it is
            // deliberately never written to `articles` — do not save a
            // figureless or schema-incomplete article.
            saveError = `Blocked by hard quality gate — article was not saved: ${hardBlockReasons.join(' | ')}`;
            console.error(`[article-v2] ${saveError}`);
          } else if (userId) {
            try {
              const db = getServiceSupabase();
              const { data: savedArticle, error: insertError } = await db
                .from('articles')
                .insert({
                  user_id: userId,
                  title: articleTitle,
                  meta_description: articleDescription,
                  content: publishedHtml,
                  keyword,
                  word_count: finalProseWordCount,
                  eeat_score: eeatScore,
                  readability_score: readabilityScore,
                  keyword_density: String(keywordDensity),
                  status: 'draft',
                  brand: brand || null, // never fabricate a company name in persisted data
                  article_url: articleUrl,
                  market,
                  schema_json: schemaJsonForDb,
                  hero_image_url: heroImageUrl || null,
                  faqs: faqs.length > 0 ? faqs : [],
                  time_anchored_claims: timeAnchoredClaimsForDb,
                  rank_score: rankScore,
                  fact_density_score: factDensityResult.score,
                  human_score: humanScore ?? null,
                  quality_score: articleQualityGate?.score ?? null,
                  quality_passed: articleQualityGate?.passed ?? null,
                  quality_issues: articleQualityGate?.issues ?? [],
                  quality_auto_fixed: articleQualityGate?.autoFixedCount ?? 0,
                  quality_ready_to_publish: articleQualityGate?.readyToPublish ?? false,
                  quality_checked_at: articleQualityGate ? new Date().toISOString() : null,
                  // entity_score/entity_count/top_entities intentionally omitted —
                  // no entity-scoring exists anywhere in this pipeline yet.
                })
                .select('id')
                .single();

              if (insertError) throw insertError;
              savedArticleId = savedArticle.id;
              console.log(`[article-v2] saved article ${savedArticleId} for user ${userId}`);

              // C04 (temporal-claims spec) registry — one row per claim
              // that passed the same-sentence citation check. Never blocks
              // the response; a failure here just means those claims won't
              // be re-verified by the freshness job, not a save failure.
              try {
                const temporalRows = buildTemporalClaimRows(finalTemporalClaims, {
                  articleId: savedArticle.id,
                  userId,
                  now: new Date(generatedAt),
                });
                if (temporalRows.length > 0) {
                  const { error: temporalInsertError } = await db.from('temporal_claims').insert(temporalRows);
                  if (temporalInsertError) throw temporalInsertError;
                  console.log(`[article-v2] registered ${temporalRows.length} temporal claim(s) for article ${savedArticleId}`);
                }
              } catch (temporalInsertErr) {
                console.warn('[article-v2] temporal_claims insert failed, continuing:', temporalInsertErr);
              }

              // Fire-and-forget — never block/fail the response on IndexNow.
              // No-ops itself (see indexnow.ts) if INDEXNOW_KEY isn't
              // configured or the URL is still the example.com placeholder.
              const indexNowUrl = fullArticleUrl || `https://example.com${articleSlug}`;
              pingIndexNow(indexNowUrl)
                .then(result => {
                  if (result.fired) console.log(`[indexnow] pinged for ${indexNowUrl}: ${result.reason}`);
                  else console.log(`[indexnow] skipped for ${indexNowUrl}: ${result.reason}`);
                })
                .catch(err => console.warn('[indexnow] ping failed:', err));

              // Fire-and-forget, matches pages.ts's "instrumentation must
              // not break the pipeline" philosophy — usage counters and
              // pipeline-stage tracking should never fail the response.
              (async () => {
                try {
                  const { data: profile } = await db
                    .from('user_profiles')
                    .select('articles_used_today, articles_used_month')
                    .eq('id', userId)
                    .single();
                  await db.from('user_profiles').update({
                    articles_used_today: (profile?.articles_used_today ?? 0) + 1,
                    articles_used_month: (profile?.articles_used_month ?? 0) + 1,
                  }).eq('id', userId);
                } catch (usageErr) {
                  console.warn('[article-v2] usage counter update failed:', usageErr);
                }
              })();

              if (pageId) {
                void stampStage(db, pageId as string, STAGE.QA, { article_id: savedArticleId });
              }
            } catch (err) {
              saveError = err instanceof Error ? err.message : String(err);
              console.error('[article-v2] FAILED to save article to Supabase:', saveError);
            }
          } else {
            saveError = 'No authenticated user — article was generated but not saved. Please sign in and regenerate.';
            console.warn('[article-v2] skipped save: no userId on request');
          }

          // Panel rings + search/ai scores MUST be scored from the final
          // published HTML (same artifact as Quality Gate), never the
          // pre-humanize draft — otherwise streamed SEORANKO_SCORES diverge
          // from the persisted quality_score / final gate.
          {
            const panel = computePanelScores(publishedHtml || finalHtml, keyword)
            eeatScore = panel.eeatScore
            readabilityScore = panel.readabilityScore
            keywordDensity = panel.keywordDensity
            keywordDensityScore = panel.keywordDensityScore
          }
          {
            const finalScores = scoreHtmlLocally(publishedHtml || finalHtml, keyword)
            searchScore = finalScores.searchScore
            aiScore = finalScores.aiScore
          }
          const scoreMeta = JSON.stringify({
            searchScore, aiScore, eeatScore, readabilityScore, keywordDensity, keywordDensityScore,
            factSourcingScore, factPatchedCount, llmsTxtEntry, humanScore, bannedWordsRemoved, passesDetection,
            rankScore,
            wordCount: finalProseWordCount,
            targetWordCount,
            articleId: savedArticleId,
            saveError,
            factDensity: {
              score: factDensityResult.score,
              grade: factDensityResult.grade,
              factsPerHundredWords: factDensityResult.factsPerHundredWords,
              suggestions: factDensityResult.suggestions,
            },
            faqs,
            answerFirst,
            hasSchema: !!schemaResult,
            schemaScriptTag: schemaResult?.combinedScriptTag ?? '',
            linkAudit,
            qualityGate: articleQualityGate,
          });
          controller.enqueue(encoder.encode(`\n<!-- SEORANKO_SCORES:${scoreMeta} -->`));

          controller.close();

          // Fire-and-forget: record score snapshot + queue 7-day citation test
          recordScoreSnapshot({
            domain: 'generated_articles',
            page_url: articleSlug,
            score: searchScore,
            ai_score: aiScore,
            source: 'article_v2',
          }).catch(() => {});
          if (citationDomain) queueCitationTest({ domain: citationDomain, topic: keyword, daysFromNow: 7, source: 'article_v2' });

        } catch (err) {
          const errMsg = err instanceof Error ? err.message : String(err)
          console.error('[article-v2] stream error:', errMsg)
          controller.enqueue(encoder.encode(
            `\n<!--SEORANKO_ERROR:${encodeURIComponent(errMsg)}-->`
          ))
          controller.close()
        }
      },
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Transfer-Encoding': 'chunked',
        'X-Content-Type-Options': 'nosniff',
      },
    });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (error: any) {
    console.error('[article-v2]', error);
    return new Response(
      JSON.stringify({ error: error?.message || 'Article generation failed' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
